﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodingCards.Models
{
    public enum CardType
    {
        Generic,
        LongAnswer,
        SysDesign,
        OopDesign
    }
}
